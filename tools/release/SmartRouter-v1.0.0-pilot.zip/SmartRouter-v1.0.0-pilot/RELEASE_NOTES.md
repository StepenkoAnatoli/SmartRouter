# SmartRouter — v1.0.0-pilot consumer package

This directory is a **consumer-ready drop** of everything a downstream host needs to adopt the
SmartRouter routing skill package, run its validation, and exercise its decision semantics.

## Contents

| Path | What it is |
| --- | --- |
| `skills/smart-router/` | Canonical five-gate routing skill (SKILL.md + 2 references) |
| `skills/smart-router-review/` | Blocker-reviewer skill (SKILL.md + 1 reference) |
| `skills/smart-router-eval-prep/` | Preregistration-prep skill (SKILL.md + 1 reference) |
| `tests/smart_router_decisions.py` | Decision suite — 79 assertions / 52 fixture IDs, exit 0 expected |
| `tests/decision_summary.py` | Per-family route-summary sidecar |
| `fixture_checks.py` | Phase-1 arithmetic/behavior smoke test |
| `tools/validate_skills.py` | Skill validator (supports `--strict` sweep promotion) |
| `docs/` | Pinned plan, preregistration, pilot report, completion record, live-start packet, P02 brief, Moonzila advisory-UI design note |
| `LICENSE` | MIT |

## Quickstart

```bash
python tools/validate_skills.py          # → exit 0, "OK: 3 skill(s) validated"
python tests/smart_router_decisions.py   # → exit 0, "79/79 assertions passed, 52/52 fixture IDs"
python tests/decision_summary.py         # → advisory-only per-family route table
python fixture_checks.py                 # → exit 0, "All arithmetic fixtures verified."
```

All four verified exit-0 in a clean unpack of this package (2026-10-10).

## What this package IS and IS NOT

- **Is**: a validated, self-contained copy of the SmartRouter policy skill package + its test
  evidence, pinned to plan revision `d7c00f96a17c35e6c47c5ba1f7e3a9160c966042`.
- **Is not**: a runtime router, a hosted service, or anything that authorizes live model spend.
  Skills are advisory-only; any live trial is gated per `docs/PHASE4_LIVE_START_PACKET.md`.

## Source / provenance

Tagged from SmartRouter main `b6e04fd` (the phase-1..4 completion tree after the merged
phase-3 preregistration chain and the Phase 4 non-live evaluation). See `docs/PROJECT_COMPLETION.md`
for the full phase ledger and `docs/PHASE4_PILOT_REPORT.md` for evaluation evidence.
